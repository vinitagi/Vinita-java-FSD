import { Component } from '@angular/core';

@Component({
  selector: 'app-change-color-directive',
  templateUrl: './change-color-directive.component.html',
  styleUrl: './change-color-directive.component.css'
})
export class ChangeColorDirectiveComponent {

}

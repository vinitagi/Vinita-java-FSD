import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ChangeColorDirectiveComponent } from './change-color-directive.component';

describe('ChangeColorDirectiveComponent', () => {
  let component: ChangeColorDirectiveComponent;
  let fixture: ComponentFixture<ChangeColorDirectiveComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ChangeColorDirectiveComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ChangeColorDirectiveComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

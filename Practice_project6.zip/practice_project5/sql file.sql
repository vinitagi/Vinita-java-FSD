CREATE DATABASE ecommerce;
USE ecommerce;
CREATE TABLE eproduct (ID bigint auto_increment primary key , name varchar(100), price decimal(10,2));
INSERT INTO eproduct values (ID,'HPLaptop', 12000) ,(ID,'AcerLaptop', 14000),(ID,'Lenevo',11000); 
/**
 * 
 */
/**
 * 
 */
module practice_project3 {
	requires java.sql;
}
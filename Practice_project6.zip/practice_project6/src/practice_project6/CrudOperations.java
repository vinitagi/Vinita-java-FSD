package practice_project6;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;



public class CrudOperations 
{
public static void main(String[] args) throws ClassNotFoundException, SQLException
{
	final String DRIVER_CLASS="com.mysql.cj.jdbc.Driver";
    final String DB_URL="jdbc:mysql://localhost:3306/jdbccrud";
	final String USERNAME="root";
	final String PASSWORD="Abi1001@";
	Class.forName(DRIVER_CLASS);
	//connection with the dB 
	Connection con=DriverManager.getConnection(DB_URL,USERNAME,PASSWORD);
	Statement st=con.createStatement();
 	ResultSet rs=st.executeQuery("select * from emp");
 	st.execute("insert into emp values(103,'abishek',23)");
	st.execute("insert into emp values(201,'nisha',24)");
	st.execute("insert into emp values(123,'nandha',27)");
	//delete data
	st.execute("delete from emp where emp_id='101'");
	//update data
	st.execute("update emp set emp_id=333 where emp_id='103'");

	con.close();
	
 	
	
}
}